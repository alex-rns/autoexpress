Converter recommended: https://www.fontsquirrel.com/tools/webfont-generator
